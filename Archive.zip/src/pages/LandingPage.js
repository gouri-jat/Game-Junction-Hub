import React from "react";
import { useNavigate } from "react-router-dom";
import "./LandingPage.css"; // CSS Import

// ✅ Yeh array automatically sabhi games ko render karega
const games = [
  { name: "Tic-Tac-Toe", route: "/tic-tac-toe", image: "/assests/logo.png" },
  { name: "Scribble", route: "/scribble", image: "/assests/logo.png" },
  { name: "Memory Game", route: "/memory-game", image: "/assests/logo.png" },
  { name: "Number Sequence", route: "/number-sequence", image: "/assests/logo.png" },
  { name: "Word Association", route: "/word-association", image: "/assests/logo.png" },
];

const LandingPage = () => {
  const navigate = useNavigate();

  return (
    <div className="landing-container">
      <h1 className="title">Game Junction</h1>
      <div className="game-grid">
        {games.map((game, index) => (
          <div key={index} className="game-card" onClick={() => navigate(game.route)}>
            <img src={game.image} alt={game.name} className="game-image" />
            <h2 className="game-name">{game.name}</h2>
          </div>
        ))}
      </div>
    </div>
  );
};

export default LandingPage;
