// src/components/GameSelection.js
import React from "react";
import { Link } from "react-router-dom";

const GameSelection = () => {
  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>Game Junction</h1>
      <p>Select a game to play:</p>
      <Link to="/tic-tac-toe"><button>Tic-Tac-Toe</button></Link>
      <Link to="/scribble"><button>Scribble</button></Link>
      <Link to="/mind-games"><button>Mind Games</button></Link>
    </div>
  );
};

export default GameSelection;
