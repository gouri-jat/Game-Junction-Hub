// src/components/Navbar.js
import React from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <nav style={{ padding: "10px", backgroundColor: "#282c34" }}>
      <Link to="/" style={{ margin: "10px", color: "#61dafb", textDecoration: "none" }}>Home</Link>
      <Link to="/tic-tac-toe" style={{ margin: "10px", color: "#61dafb", textDecoration: "none" }}>Tic-Tac-Toe</Link>
      <Link to="/scribble" style={{ margin: "10px", color: "#61dafb", textDecoration: "none" }}>Scribble</Link>
      <Link to="/mind-games" style={{ margin: "10px", color: "#61dafb", textDecoration: "none" }}>Mind Games</Link>
    </nav>
  );
};

export default Navbar;
