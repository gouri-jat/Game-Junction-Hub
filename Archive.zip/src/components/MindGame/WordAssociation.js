import React, { useState } from "react";

const wordPairs = {
  Sun: "Moon",
  King: "Queen",
  Fire: "Water",
  Day: "Night",
  Hot: "Cold",
};

const WordAssociation = () => {
  const words = Object.keys(wordPairs);
  const randomWord = words[Math.floor(Math.random() * words.length)];

  const [selectedWord] = useState(randomWord);
  const [userInput, setUserInput] = useState("");
  const [message, setMessage] = useState("");

  const checkAnswer = () => {
    if (userInput.toLowerCase() === wordPairs[selectedWord].toLowerCase()) {
      setMessage("✅ Correct!");
    } else {
      setMessage("❌ Wrong! Try again.");
    }
  };

  return (
    <div>
      <h2>Word Association</h2>
      <p>What is the opposite of: <strong>{selectedWord}</strong>?</p>
      <input type="text" value={userInput} onChange={(e) => setUserInput(e.target.value)} placeholder="Type your answer" />
      <button onClick={checkAnswer}>Submit</button>
      <p>{message}</p>
    </div>
  );
};

export default WordAssociation;
