import React, { useState } from "react";

const NumberSequence = () => {
  const [sequence, setSequence] = useState([]);
  const [userInput, setUserInput] = useState("");
  const [message, setMessage] = useState("");
  const [missingNumber, setMissingNumber] = useState(null);

  const generateSequence = () => {
    let newSeq = [];
    let start = Math.floor(Math.random() * 10) + 1;
    let step = Math.floor(Math.random() * 5) + 1;

    for (let i = 0; i < 5; i++) {
      newSeq.push(start + i * step);
    }

    setMissingNumber(newSeq[4]); // Last number hide kar diya
    setSequence(newSeq.slice(0, 4)); // Sirf first 4 numbers dikhana hai
    setUserInput("");
    
    setMessage("");
  };

  const checkAnswer = () => {
    if (parseInt(userInput, 10) === missingNumber) {
      setMessage("✅ Correct!");
    } else {
      setMessage(`❌ Wrong! The correct answer was ${missingNumber}`);
    }
  };

  return (
    <div style={{ textAlign: "center", fontFamily: "Arial" }}>
      <h2>Number Sequence Puzzle</h2>
      <p>Complete the pattern: {sequence.join(", ")} , ?</p>
      <input
        type="number"
        value={userInput}
        onChange={(e) => setUserInput(e.target.value)}
        placeholder="Enter the missing number"
      />
      <div style={{ margin: "10px" }}>
        <button onClick={checkAnswer} style={{ marginRight: "10px" }}>Check</button>
        <button onClick={generateSequence}>New Puzzle</button>
      </div>
      <p>{message}</p>
    </div>
  );
};

export default NumberSequence;
