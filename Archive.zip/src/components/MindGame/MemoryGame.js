import React, { useState } from "react";

const cardsArray = ["🔥", "🌟", "💎", "🎵", "🚀", "🎮"];
const shuffledCards = [...cardsArray, ...cardsArray].sort(() => Math.random() - 0.5);

const MemoryGame = () => {
  const [selected, setSelected] = useState([]);
  const [matched, setMatched] = useState([]);

  const handleCardClick = (index) => {
    if (selected.length < 2 && !selected.includes(index) && !matched.includes(index)) {
      const newSelected = [...selected, index];

      if (newSelected.length === 2) {
        const [first, second] = newSelected;
        if (shuffledCards[first] === shuffledCards[second]) {
          setMatched([...matched, first, second]);
        }
        setTimeout(() => setSelected([]), 800);
      }

      setSelected(newSelected);
    }
  };

  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 80px)", gap: "10px", justifyContent: "center" }}>
      {shuffledCards.map((card, index) => (
        <div
          key={index}
          onClick={() => handleCardClick(index)}
          style={{
            width: "80px",
            height: "80px",
            backgroundColor: matched.includes(index) || selected.includes(index) ? "#4CAF50" : "#ccc",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            fontSize: "30px",
            cursor: "pointer",
          }}
        >
          {matched.includes(index) || selected.includes(index) ? card : "❓"}
        </div>
      ))}
    </div>
  );
};

export default MemoryGame;
