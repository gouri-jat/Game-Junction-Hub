
import { useState } from "react";
import "../components/MindGame/TicTacToe.css"; 
const TicTacToe = () => {
  const [board, setBoard] = useState(Array(9).fill(null));
  const [isXNext, setIsXNext] = useState(true);

  const checkWinner = (squares) => {
    const winningCombinations = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8],
      [0, 3, 6], [1, 4, 7], [2, 5, 8],
      [0, 4, 8], [2, 4, 6]
    ];
    for (let [a, b, c] of winningCombinations) {
      if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
        return squares[a];
      }
    }
    return null;
  };

  const handleClick = (index) => {
    if (board[index] || checkWinner(board)) return;
    
    const newBoard = [...board];
    newBoard[index] = isXNext ? "X" : "O";
    setBoard(newBoard);
    setIsXNext(!isXNext);
  };

  const winner = checkWinner(board);
  const isDraw = board.every(cell => cell !== null) && !winner;

  const resetGame = () => {
    setBoard(Array(9).fill(null));
    setIsXNext(true);
  };

  return (
    <div className="flex flex-col items-center gap-4 p-4">
      <h1 className="text-2xl font-bold">Tic-Tac-Toe</h1>
      <div className="grid grid-cols-3 gap-2 w-48">
      <div className="tic-tac-toe">
      <h1>Tic-Tac-Toe</h1>
      <div className="board">
        
      
    
        {board.map((cell, index) => (
          <button
            key={index}
            className="w-16 h-16 flex items-center justify-center text-xl font-bold border border-gray-500"
            onClick={() => handleClick(index)}
          >
            {cell}
          </button>
        ))}
        </div>
      </div>
      </div>
      {winner && <p className="text-lg font-semibold">Winner: {winner} 🎉</p>}
      {isDraw && <p className="text-lg font-semibold">It's a Draw! 🤝</p>}
      <button 
        className="mt-4 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
        onClick={resetGame}
      >
        Restart Game
      </button>
    </div>
  );
};

export default TicTacToe;


