import { useRef } from "react";
//import { SketchPicker } from "react-color";
import { ReactSketchCanvas } from "react-sketch-canvas";

const ScribbleGame = () => {
  const canvasRef = useRef(null);

  const clearCanvas = () => {
    if (canvasRef.current) {
      canvasRef.current.clearCanvas();
    }
  };

  return (
    <div className="flex flex-col items-center gap-4 p-4">
      <h1 className="text-2xl font-bold">Scribble Game</h1>
      <ReactSketchCanvas
        ref={canvasRef}
        strokeWidth={4}
        strokeColor="black"
        width="400px"
        height="400px"
        className="border border-gray-500"
      />
      <button
        className="mt-4 px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600"
        onClick={clearCanvas}
      >
        Clear Canvas
      </button>
    </div>
  );
};

export default ScribbleGame;
