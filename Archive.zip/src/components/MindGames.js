import React, { useState } from "react";
import MemoryGame from "./MindGame/MemoryGame";
import NumberSequence from "./MindGame/NumberSequence";
import WordAssociation from "./MindGame/WordAssociation";

const MindGames = () => {
  const [selectedGame, setSelectedGame] = useState(null);

  return (
    <div style={{ textAlign: "center", marginTop: "20px" }}>
      <h1>Mind Games</h1>
      {!selectedGame ? (
        <div>
          <button onClick={() => setSelectedGame("memory")}>Memory Game</button>
          <button onClick={() => setSelectedGame("number")}>Number Sequence</button>
          <button onClick={() => setSelectedGame("word")}>Word Association</button>
        </div>
      ) : (
        <div>
          {selectedGame === "memory" && <MemoryGame />}
          {selectedGame === "number" && <NumberSequence />}
          {selectedGame === "word" && <WordAssociation />}
          <button onClick={() => setSelectedGame(null)}>Back to Menu</button>
        </div>
      )}
    </div>
  );
};

export default MindGames;
