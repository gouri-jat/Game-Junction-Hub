import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import LandingPage from "./pages/LandingPage";
import TicTacToe from "./components/TicTacToe";
import Scribble from "./components/Scribble";
import MindGames from "./components/MindGames";
import MemoryGame from "./components/MindGame/MemoryGame";
import NumberSequence from "./components/MindGame/NumberSequence";
import WordAssociation from "./components/MindGame/WordAssociation";







function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        
        
        
      
    
    
        <Route path="/tic-tac-toe" element={<TicTacToe />} />
        <Route path="/scribble" element={<Scribble />} />
        <Route path="/mind-games" element={<MindGames />} />
        <Route path="/memory-game" element={<MemoryGame />} />
        <Route path="/number-sequence" element={<NumberSequence />} />
        <Route path="/word-association" element={<WordAssociation />} />
        
      </Routes>
    </Router>
   
  );
}

export default App;
